$( function() {
    $( "#datepicker" ).datepicker();
  } );